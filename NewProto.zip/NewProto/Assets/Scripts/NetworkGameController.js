﻿#pragma strict

var spawnPosition: GameObject;
var playerPrefab: GameObject;

function Start () 
{
 //start receiving message again
 Network.isMessageQueueRunning = true;
  
 //start sending messages again
 Network.SetSendingEnabled(0, true);
  
 //load in a player
 Network.Instantiate(playerPrefab, spawnPosition.transform.position, spawnPosition.transform.rotation, 0);
}

function Update () {

}