﻿using UnityEngine;
using System.Collections;

public class Item {
	public Texture itemImage = (Texture2D)Resources.Load("alphaTemp");
	public int xSize = 0;
	public int ySize = 0;
	public string name = "";
	public string prefabName = "";
	
	public Item(Texture image, string itemName, int x, int y, string prefab){
		itemImage = image;
		name = itemName;
		xSize = x;
		ySize = y;
		prefabName = prefab;
	}
	public Item(){
		itemImage = itemImage;
		name = "";
		xSize = 1;
		ySize = 1;
		prefabName = "";
	}
}
