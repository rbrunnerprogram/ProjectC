﻿#pragma strict

import System;

var creepingSpeed : float = 2.0;
var walkingSpeed : float = 6.0;
var joggingSpeed : float = 16.0;
var sprintingSpeed : float = 30.0;

var speedOneUp : boolean = false;
var speedOneDown : boolean = false;

var movementSpeed : float = 0.0;

var positions = new Array();

var currentPosition : float = 0.0;

var prone : float = 0.1;
var crouching : float = 0.5;
var standing : float = 1.0;

positions = [prone, crouching, standing];
var speedAndStance = [[creepingSpeed, walkingSpeed], [creepingSpeed, walkingSpeed, joggingSpeed], [walkingSpeed, joggingSpeed, sprintingSpeed]];

var jumpSpeed : float = 8.0;
var gravity : float = 20.0;

private var moveDirection : Vector3 = Vector3.zero;

var cameraObject : GameObject;

var oldX : float = 0.0;
var oldZ : float = 0.0;
var newX : float = 0.0;
var newZ : float = 0.0;
var totalDistance : float = 0.0;
var dist : float = 0.0;
var stepLength : float;
stepLength = 5.0;
var prefab : Transform;

var crouchRacio : float = 0.5;
var transitionToCrouchSec : float = 0.2;
var crouchingVelocity : float;
var currentCrouchRacio : float = 1;
var coriginalLocalScaleY : float;
var crouchLocalScaleY : float;

var standDownCrouch : boolean = false;
var crouchUpStand : boolean = false;

var proneRacio : float = 0.2;
var transitionToProneSec : float = 0.2;
var proningVelocity : float;
var currentProneRacio : float = 1;
var poriginalLocalScaleY : float;
var proneLocalScaleY : float;

var crouchDownProne : boolean = false;
var proneUpCrouch : boolean = false;

var shorterLocalScaleY : float;
var currentShortRacio : float;
var originalLocalScaleY : float;
 
var maxDist : float = 5.0;
var decalHitWall : GameObject;
var floatInFrontOfWall : float = 0.01;
var hit : RaycastHit;

var rotation : Quaternion = Quaternion(0, 9999, 0, 0);

function Start () {
	currentPosition = positions[2];
	movementSpeed = speedAndStance[2][1];

	currentCrouchRacio = 1;
    //coriginalLocalScaleY = transform.localScale.y;
    //crouchLocalScaleY = transform.localScale.y * crouchRacio;
    
    currentProneRacio = 1;
    //poriginalLocalScaleY = transform.localScale.y;
    //proneLocalScaleY = transform.localScale.y * proneRacio;
    
    currentShortRacio = 1;
    //originalLocalScaleY = transform.localScale.y;
    //shorterLocalScaleY = transform.localScale.y * currentShortRacio;
}

function Update ()
{
	if (!networkView.isMine){
	
	GetComponentInChildren(Camera).enabled = false; 
	
	// disable the camera of the non-owned Player; 
	
	GetComponentInChildren(AudioListener).enabled = false; 
	
	// Disables AudioListener of non-owned Player - prevents multiple AudioListeners from being present in scene. 
	
	GetComponentInChildren(MouseLook).enabled = false;
	GetComponentInChildren(PlayerMovement).enabled = false; 
	
	} 
	
    /*if (Input.GetButton("Crouch")){
        currentCrouchRacio = Mathf.SmoothDamp(currentCrouchRacio, 0, crouchingVelocity, transitionToCrouchSec);
	}
    if (Input.GetButton("Crouch") == false && collisionDetectionSphere.GetComponent(CollsionDetectionSphereScript).collisionDetected == false){
        currentCrouchRacio = Mathf.SmoothDamp(currentCrouchRacio, 1, crouchingVelocity, transitionToCrouchSec);
    }*/
	
	transform.rotation = Quaternion.Euler(0, cameraObject.GetComponent(MouseLook).currentYRotation, 0);
	//currentCrouchRacio = Mathf.SmoothDamp(currentCrouchRacio, 0, crouchingVelocity, transitionToCrouchSec);
	
	var controller : CharacterController = GetComponent(CharacterController);
    
    /*if (currentPosition == positions[2]){
    	Debug.Log("blargle");
    	transform.localScale.y = Mathf.Lerp(crouchLocalScaleY, originalLocalScaleY, currentCrouchRacio);
    }*/
    
    /*if(currentPosition == positions[1]){
    	transform.localScale.y = Mathf.Lerp(crouchLocalScaleY, originalLocalScaleY, currentCrouchRacio);
    	}
    if(currentPosition == positions[0]){
    	transform.localScale.y = Mathf.Lerp(proneLocalScaleY, originalLocalScaleY, currentProneRacio);
    	}*/
    if(currentPosition == positions[2]){
    	shorterLocalScaleY = 0.5;
    	originalLocalScaleY = 1;
    	currentShortRacio = 1;
    	
    	}
    if(currentPosition == positions[1]){
    	shorterLocalScaleY = 0.7;
    	originalLocalScaleY = 1;
    	currentShortRacio = currentCrouchRacio;
    	
    	}
    if(currentPosition == positions[0]){
    	shorterLocalScaleY = 0.4;
    	originalLocalScaleY = 0.5;
    	currentShortRacio = currentProneRacio;
    	
    	}
    transform.localScale.y = Mathf.Lerp(shorterLocalScaleY, originalLocalScaleY, currentShortRacio);
    //transform.localScale.y = Mathf.Lerp(proneLocalScaleY, originalLocalScaleY, currentProneRacio);
    //currentCrouchRacio = Mathf.SmoothDamp(currentCrouchRacio, 1, crouchingVelocity, transitionToCrouchSec);
    
    if (Input.GetKeyDown("left alt")){ // press C to crouch
        
        if(currentPosition == positions[2]){
			crouchUpStand = false;
			currentPosition = positions[1];
			movementSpeed = speedAndStance[1][1];
			//currentCrouchRacio = Mathf.SmoothDamp(currentCrouchRacio, 0, crouchingVelocity, transitionToCrouchSec);
			standDownCrouch = true;
			}
		else if(currentPosition == positions[1]){
			proneUpCrouch = false;
			currentPosition = positions[0];
			movementSpeed = speedAndStance[0][0];
			crouchDownProne = true;
			transform.position.y = 1.2;
			}
    }
    
    if(standDownCrouch){
    	Debug.Log("blargle");
		currentCrouchRacio = Mathf.SmoothDamp(currentCrouchRacio, 0, crouchingVelocity, transitionToCrouchSec);
		
		}
		
	if(crouchDownProne){
    	Debug.Log("blargle2");
		currentProneRacio = Mathf.SmoothDamp(currentProneRacio, 0, proningVelocity, transitionToProneSec);
		
		}
    
    if(Input.GetKeyDown("left shift"))
    	speedOneUp = true;
    if(Input.GetKeyUp("left shift"))
    	speedOneUp = false;
    	
    if(Input.GetKeyDown("left ctrl"))
    	speedOneDown = true;
    if(Input.GetKeyUp("left ctrl"))
    	speedOneDown = false;
    
	if((speedOneUp == false) && (speedOneDown == false)){
		if(currentPosition == positions[2]){
			movementSpeed = speedAndStance[2][1];
			}
		else if(currentPosition == positions[1]){
			movementSpeed = speedAndStance[1][1];
			}
		else if(currentPosition == positions[0]){
			movementSpeed = speedAndStance[0][0];
			}
		}
	else if(speedOneUp){
		if(currentPosition == positions[2]){
			movementSpeed = speedAndStance[2][2];
			}
		else if(currentPosition == positions[1]){
			movementSpeed = speedAndStance[1][2];
			}
		else if(currentPosition == positions[0]){
			movementSpeed = speedAndStance[0][1];
			}
		}
	else if(speedOneDown){
		if(currentPosition == positions[2]){
			movementSpeed = speedAndStance[2][0];
			}
		else if(currentPosition == positions[1]){
			movementSpeed = speedAndStance[1][0];
			}
		}
    
    if (controller.isGrounded) {
		// We are grounded, so recalculate
		// move direction directly from axes
		moveDirection = Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
		moveDirection = transform.TransformDirection(moveDirection);
		moveDirection *= movementSpeed;
		
		if (Input.GetKeyDown("space")) {
			if(currentPosition == positions[2]){
				moveDirection.y = jumpSpeed;
				}
			else if(currentPosition == positions[1]){
				standDownCrouch = false;
				currentPosition = positions[2];
				movementSpeed = speedAndStance[2][1];
				//currentCrouchRacio = Mathf.SmoothDamp(currentCrouchRacio, 1, crouchingVelocity, transitionToCrouchSec);
				crouchUpStand = true;
				transform.position.y = 1.2;
				}
			else if(currentPosition == positions[0]){
				crouchDownProne = false;
				currentPosition = positions[1];
				movementSpeed = speedAndStance[1][1];
				proneUpCrouch = true;
				transform.position.y = 1.0;
				}
		}
		
	}
	if(crouchUpStand){
		Debug.Log("blargle3");
		currentCrouchRacio = Mathf.SmoothDamp(currentCrouchRacio, 1, crouchingVelocity, 0.05);	
	}
	if(proneUpCrouch){
		Debug.Log("blargle4");
		currentProneRacio = Mathf.SmoothDamp(currentProneRacio, 1, proningVelocity, 0.05);	
	}
	// Apply gravity
	moveDirection.y -= gravity * Time.deltaTime;
    
    // Move the controller
    oldX = controller.transform.position.x;
    oldZ = controller.transform.position.z;
    controller.Move(moveDirection * Time.deltaTime);
    newX = controller.transform.position.x;
    newZ = controller.transform.position.z;
    dist = Math.Sqrt(Math.Pow((newX-oldX),2) + Math.Pow((newZ-oldZ),2));
    totalDistance += dist;
    
    if(totalDistance >= stepLength)
    {
    	totalDistance = 0.0;
    	//makeTrack();
    	if (Physics.Raycast(transform.position, Vector3(0, -1, 0), hit, maxDist))//transform.up, hit, maxDist))
	    {
	        Debug.Log("Track made!! kar01");
	        /*if (decalHitWall && hit.transform.tag == "Level Parts")
	        {
	            Debug.Log("Track made!! kar02");
	            Network.Instantiate(decalHitWall, hit.point + (hit.normal * floatInFrontOfWall), Quaternion.LookRotation(hit.normal), 0);
	        }*/
	        Debug.Log("Track made!! kar02");
	        Network.Instantiate(decalHitWall, hit.point + (hit.normal * floatInFrontOfWall), transform.rotation * Quaternion.Euler(0, 90, 0), 0);//LookRotation(hit.normal), 0);
	    }
	    Debug.Log("Track made!! kar03");
    }
    
    /*if (Physics.Raycast(transform.position, transform.up, hit, maxDist))
    {
        if (decalHitWall && hit.transform.tag == "Level Parts")
            Instantiate(decalHitWall, hit.point + (hit.normal * floatInFrontOfWall), Quaternion.LookRotation(hit.normal));
    }*/
    //Destroy(gameObject);

}

/*function makeTrack() {
	Network.Instantiate(prefab, transform.position, Quaternion.identity, 0);
	Debug.Log("Track made!!");
}*/