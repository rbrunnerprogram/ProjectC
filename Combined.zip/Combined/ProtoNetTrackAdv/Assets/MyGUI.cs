﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
public class MyGUI : MonoBehaviour {
	public GUISkin mySkin;
	public float inventoryWindowHeight = 100;
	
	public static int inventoryWidth = 10;
	public static int inventoryHeight = 5;
	public static int windowWidth = 800;
	public static int windowHeight = 400;
	public static int windowOffsetX = 200;
	public static int windowOffsetY = 100;
	
	private bool _displayInventoryWindow = false;
	private int _cellWidth = windowWidth/inventoryWidth;
	private int _cellHeight = windowHeight/inventoryHeight;
	private int currentX = 0;
	private int currentY = 0;
	private int currentMouseX = 0;
	private int currentMouseY = 0;
	private int oldMouseX = 0;
	private int oldMouseY = 0;
	private int activeX = 0;
	private int activeY = 0;
	private Item activeItem;
	private Item[,] inventoryList = new Item[inventoryHeight,inventoryWidth];
	private bool doThis = true; // this is a terrible bandaid
	public Texture2D border;
	private bool dragging = false;
	public Texture2D invBG;
	public Texture2D medkitImage;
	public Texture2D knifeImage;
	public Texture2D activeCellImage;
	public Texture2D dragBarImage;
	public Rect dragRect;
	public Item blank;
	public Item activeGameItem = null;
	public Texture2D activeGameItemImage;
	public bool hasActiveGameItem = false;
	public bool draggingActiveGameItem = false;
	public int activeGameItemX = 0;
	public int activeGameItemY = 0;
	public GameObject activeGameItemPrefab;
	public GameObject knifePrefab;
	public Item knife;
	public Item medkit;
	public GameObject activeItemInstantiation;
	public NetworkViewID viewID;
	public Vector3 euler;
	
	//Active Game Item stuff
	//private Transform currentItem;
	public GameObject currentItem;
	
	public GameObject cameraObject;
	
	//public bool isItemMoving = false;
	//public float stabDistance = 0;
	public float stabTime = 0;
	
	
	void Start(){
		
		activeGameItemImage = (Texture2D)Resources.Load ("activeGameItem");
		invBG = (Texture2D)Resources.Load("invBackgroundImage");
		dragBarImage = (Texture2D)Resources.Load("dragBar");
		activeCellImage = (Texture2D)Resources.Load ("activeCell");
		medkitImage = (Texture2D)Resources.Load ("medkitImage");
		knifeImage = (Texture2D)Resources.Load("knifeImage");
		border = (Texture2D)Resources.Load ("EmptyBorder");
		Item medkit = new Item(medkitImage, "Medkit", 1, 1, "medkit");
		Item knife = new Item(knifeImage, "Knife", 2, 1, "knife2");
		blank = new Item();
		euler = cameraObject.transform.rotation.eulerAngles/360;
		
		updateInventoryList(medkit);
		updateInventoryList(knife);
	}
	
	void updateInventoryList(Item item){
		bool breakLoop = false;
		bool inventoryHasSpace = true;
		for(int i = 0; i < inventoryHeight;i++){
			for (int j = 0; j<inventoryWidth;j++){
				if (inventoryList[i,j] == null){
					inventoryHasSpace = true;
					for (int k = i; k < i + item.ySize; k++){
						for (int l = j; l < j + item.xSize; l++){
							if(l > 9)
								inventoryHasSpace = false;
							else if (inventoryList[k,l] != null)
								inventoryHasSpace = false;
						}
						if(k > inventoryHeight)
							inventoryHasSpace = false;	
					}
					if(inventoryHasSpace == true){
						inventoryList[i,j] = item;
						for (int k = i; k < i + item.ySize; k++){
							for (int l = j; l < j + item.xSize; l++){
								if(inventoryList[k,l] == null){
									inventoryList[k, l] = blank;
								}
							}
						}
						breakLoop = true;	
					}
				}
				if (breakLoop)
					break;
			}
			if (breakLoop)
				break;
		}
	}
	
	void OnGUI(){
		
		if(_displayInventoryWindow){
			GUI.DrawTexture(new Rect(windowOffsetX,windowOffsetY,windowWidth,windowHeight),invBG,ScaleMode.ScaleToFit,true,0);
			dragRect = new Rect(windowWidth - 240 + windowOffsetX,windowHeight + windowOffsetY,240,80);
			GUI.DrawTexture(dragRect,dragBarImage,ScaleMode.ScaleToFit,true,0);
			for(int j = 0;j < inventoryWidth;j++){
				for(int i = 0;i < inventoryHeight;i++) {
					if(_displayInventoryWindow){
						GUI.DrawTexture(new Rect(j*80 + windowOffsetX,i*80 + windowOffsetY,80,80),border,ScaleMode.ScaleToFit,true,0);
					}
				}
			}
			for(int j = 0;j < inventoryWidth;j++){
				for(int i = 0;i < inventoryHeight;i++) {
					if(_displayInventoryWindow){
						if(inventoryList[i,j] != null){
							GUI.DrawTexture(new Rect(j*80 + windowOffsetX,i*80 + windowOffsetY,80 * inventoryList[i,j].xSize,80 * inventoryList[i,j].ySize),inventoryList[i,j].itemImage,ScaleMode.ScaleToFit,true,0);
						}
					}
				}
			}
			
			doThis = !doThis;
			if(doThis){
				getCurrentXY();// for some reason OnGui calls CreateInventory 2x, so this makes the invetory stuff only one of those two times	
			}
			
			if(hasActiveGameItem == true && draggingActiveGameItem == false)
			{
				GUI.DrawTexture(new Rect(activeGameItemX*80 + windowOffsetX,activeGameItemY*80 + windowOffsetY,80 * activeGameItem.xSize, 80 * activeGameItem.ySize),activeGameItemImage,ScaleMode.StretchToFill,true,0);	
			}
		}
		
		
	}
	
	void getCurrentXY(){
		currentX = (int)Math.Floor(Event.current.mousePosition.x - windowOffsetX)/_cellWidth;
		currentY = (int)Math.Floor(Event.current.mousePosition.y - windowOffsetY)/_cellHeight;
		currentMouseX = (int)Math.Floor(Event.current.mousePosition.x);
		currentMouseY = (int)Math.Floor(Event.current.mousePosition.y);
		if(_displayInventoryWindow && Event.current.mousePosition.y - windowOffsetY < windowHeight && Event.current.mousePosition.x - windowOffsetX < windowWidth && Event.current.mousePosition.y - windowOffsetY > 0 && Event.current.mousePosition.x - windowOffsetX > 0)
		{	//highlights hovered-over cell
			GUI.DrawTexture(new Rect(currentX * _cellWidth + windowOffsetX,currentY * _cellHeight + windowOffsetY,80,80),activeCellImage,ScaleMode.ScaleToFit,true,0);
		}
		if(activeItem != null)
		{	//locks active item image to cursor
			GUI.DrawTexture(new Rect(Event.current.mousePosition.x - 40 * activeItem.xSize,Event.current.mousePosition.y - 40 * activeItem.ySize,activeItem.xSize * 80,activeItem.ySize * 80),activeItem.itemImage,ScaleMode.ScaleToFit,true,0);
			if(activeGameItem == activeItem)
			{
				//GUI.DrawTexture(new Rect(Event.current.mousePosition.x - 40 * activeItem.xSize,Event.current.mousePosition.y - 40 * activeItem.ySize,activeItem.xSize * 80,activeItem.ySize * 80),activeGameItemImage,ScaleMode.ScaleToFit,true,0);
				GUI.DrawTexture(new Rect(Event.current.mousePosition.x - 40 * activeItem.xSize,Event.current.mousePosition.y - 40 * activeItem.ySize,80 * activeGameItem.xSize, 80 * activeGameItem.ySize),activeGameItemImage,ScaleMode.StretchToFill,true,0);
				draggingActiveGameItem = true;
			}
			else
				draggingActiveGameItem = false;
		}
	}
	
	void addItem(Item itemToAdd, int newX, int newY)
	{
		inventoryList[newY, newX] = itemToAdd;
		for(int i = newY; i < newY + itemToAdd.ySize; i++)
		{
			for(int j = newX; j < newX + itemToAdd.xSize; j++)
			{
				if(inventoryList[i,j] == null)
					inventoryList[i,j] = blank;
			}
		}
	}
	
	void destroyItem(int row, int column)
	{
		int width = inventoryList[row, column].xSize;
		int height = inventoryList[row, column].ySize;
		for(int i = row; i < row + height; i++)
		{
			for(int j = column; j < column + width; j++)
			{
				if(inventoryList[i,j] != null)
					inventoryList[i,j] = null;
			}
		}
	}
	
	void Update () {
		
		float current = transform.rotation.eulerAngles.y;
		float wanted = cameraObject.transform.rotation.eulerAngles.y;
		float zero = 0;
		float currentRotationAngle = Mathf.LerpAngle (current, wanted, zero);
		transform.rotation = Quaternion.Euler (0, currentRotationAngle, 0);
		
		/*if (stabDistance == 1)
		{
			isItemMoving = false;
		}
		if(!_displayInventoryWindow && Input.GetMouseButtonDown(0))
		{
			
			isItemMoving = true;
			stabDistance = Mathf.Lerp(0, 1, Time.time);
			
			Debug.Log(stabDistance);
			Vector3 relative = transform.TransformDirection(new Vector3(0,0,stabDistance));
			currentItem.transform.position = (cameraObject.transform.position + relative);
		}
		else if(activeGameItemPrefab && !isItemMoving)
		{
			Vector3 relative = transform.TransformDirection(new Vector3(0,0,1));
			Vector3 product = Vector3.Cross(relative, euler);
			currentItem.transform.position = (cameraObject.transform.position + relative + product);
		}*/
		if(stabTime > 0)
		{
			stabTime -= Time.deltaTime;
		}
		if(!_displayInventoryWindow && Input.GetMouseButtonDown(0))
		{
			Vector3 relative = transform.TransformDirection(new Vector3(0,0,2));
			currentItem.transform.position = (cameraObject.transform.position + relative);
			stabTime = 1;
		}
		else if(activeGameItemPrefab && stabTime <= 0)
		{
			Vector3 relative = transform.TransformDirection(new Vector3(0,0,1));
			Vector3 product = Vector3.Cross(relative, euler);
			currentItem.transform.position = (cameraObject.transform.position + relative + product);
		}
		
		if(Input.GetKeyDown(KeyCode.Tab))
			_displayInventoryWindow = !_displayInventoryWindow;
		if(Input.GetMouseButtonDown(1) && _displayInventoryWindow)
		{
			activeGameItem = inventoryList[currentY, currentX];
			activeGameItemX = currentX;
			activeGameItemY = currentY;
			while(activeGameItem == blank)
			{
				activeGameItem = inventoryList[currentY, currentX - 1];
				activeGameItemX--;
			}
			
			if(activeGameItemPrefab)
			{
				Destroy(currentItem);
				hasActiveGameItem = false;
			}
			activeGameItemPrefab = (GameObject)Resources.Load(activeGameItem.prefabName);
			currentItem = Instantiate(activeGameItemPrefab, transform.position, Quaternion.identity) as GameObject;// as Transform; 
			hasActiveGameItem = true;
		}
		
		//currentItem.transform.position = (transform.position + new Vector3(1, 0, 1));
		if(activeGameItemPrefab)
		{
			currentItem.transform.rotation = cameraObject.transform.rotation;
		}
		
		if(Input.GetMouseButtonDown(0))
		{
			if(dragRect.Contains(new Vector2(currentMouseX,currentMouseY)))
			{
				oldMouseX = currentMouseX;
				oldMouseY = currentMouseY;
				dragging = true;
			}
			else
			{
				while(inventoryList[currentY, currentX] == blank)
					currentX--;
				activeY = currentY;
				activeX = currentX;
				activeItem = inventoryList[activeY, activeX];
				destroyItem(activeY, activeX);
			}
		}
		if (dragging)
		{
			windowOffsetX = windowOffsetX + currentMouseX - oldMouseX;
			windowOffsetY = windowOffsetY + currentMouseY - oldMouseY;
			oldMouseX = currentMouseX;
			oldMouseY = currentMouseY;
		}
		if(Input.GetMouseButtonUp(0))
		{
			if(draggingActiveGameItem == true)
			{
				if(currentY > inventoryHeight - 1 || currentX > inventoryWidth - 1 || currentMouseX < windowOffsetX || currentMouseY < windowOffsetY){}
				else
				{
					activeGameItemX = currentX;
					activeGameItemY = currentY;	
				}
				draggingActiveGameItem = false;	
			}
			
			if(dragging)
				dragging = false;
			bool inventoryHasSpace = true;
			for(int i = currentY; i < currentY + activeItem.ySize; i++)
			{
				for(int j = currentX; j < currentX + activeItem.xSize; j++)
				{
					if(i > inventoryHeight - 1 || j > inventoryWidth - 1 || currentMouseX < windowOffsetX || currentMouseY < windowOffsetY)
					{
						inventoryHasSpace = false;	
					}
					else if(inventoryList[i,j] != null)
					{
						inventoryHasSpace = false;
					}
				}
			}
			if(inventoryHasSpace == true)
			{
				addItem (activeItem, currentX, currentY);
			}
			else if(inventoryHasSpace == false)
			{
				addItem (activeItem, activeX, activeY);	
			}
			activeItem = null;
		}
	}
}
