﻿#pragma strict

var menuState = "intro";

private var gameName = "";

var gameType = "Ant Game";

function OnGUI()
{
 //switch based on state
 if(menuState == "intro")
 {
 	//host game button
 	if(GUI.Button(Rect(10, 10, 150, 50), "Host Game"))
 	{
 	 menuState = "hostGame";
 	}
 	 
 	if(GUI.Button(Rect(10, 70, 150, 50), "Join Game"))
 	{
 	 menuState = "joinGame";
 	 MasterServer.RequestHostList(gameType);
 	}
  
 }//end intro state
 else if(menuState == "hostGame")
 {
 	GUI.Label(Rect(10, 10, 200, 20), "Game Name: ");
 	 
 	gameName = GUI.TextField(Rect(10, 30, 200, 120), gameName, 40);
 	 
 	if(GUI.Button(Rect(10, 165, 150, 100), "Begin Game"))
 	{
 	 Debug.Log("Click Begin Game");
 	 LaunchServer();
 	}
 }//end host game state
 else if(menuState == "joinGame")
 {
 	var data:HostData[] = MasterServer.PollHostList();
 	 
 	for(var element in data)
 	{
 	 GUILayout.BeginHorizontal();
 	 var name = element.gameName + " " + element.connectedPlayers + " / " + element.playerLimit;
 	 GUILayout.Label(name);
 	 GUILayout.Space(5); //put five pixels of space between last and next
 	 GUILayout.Label(element.comment);
 	 GUILayout.FlexibleSpace();
 	 Debug.Log("useNat: " + element.useNat);
 	  
 	 if(GUILayout.Button("Connect"))
 	 {
 	 Debug.Log("Trying to connect");
 	 Network.Connect(element);
 	 }
 	  
 	 //stop horizontal layout
 	 GUILayout.EndHorizontal();
 	}
 }
}

function LaunchServer()
{
 Debug.Log("I am getting called");
  
 var useNAT = !Network.HavePublicAddress();
  
 Network.InitializeServer(8, 25000, useNAT);
  
 MasterServer.RegisterHost(gameType, gameName, "Ant Game");
}

function OnServerInitialized()
{
 Debug.Log("Server is setup and running");
 networkView.RPC("LoadLevel", RPCMode.AllBuffered, "player", 2);
}

@RPC
function LoadLevel(sceneName:String, levelPrefix:int)
{
 //stop sending messages for now
 Network.SetSendingEnabled(0, false);
  
 //stop getting messages
 Network.isMessageQueueRunning = false;
  
 Application.LoadLevel(sceneName);
 yield;
 yield;
}