﻿#pragma strict

import System;



var creepingSpeed : float = 2.0;
var walkingSpeed : float = 6.0;
var joggingSpeed : float = 16.0;
var sprintingSpeed : float = 30.0;



var speedOneUp : boolean = false;
var speedOneDown : boolean = false;

var movementSpeed : float = 0.0;

var positions = new Array();


var currentPosition : float = 0.0;

var prone : float = 0.1;
var crouching : float = 0.5;
var standing : float = 1.0;

positions = [prone, crouching, standing];
var speedAndStance = [[creepingSpeed, walkingSpeed], [creepingSpeed, walkingSpeed, joggingSpeed], [walkingSpeed, joggingSpeed, sprintingSpeed]];

var jumpSpeed : float = 8.0;
var gravity : float = 20.0;

private var moveDirection : Vector3 = Vector3.zero;


var cameraObject : GameObject;


var oldX : float = 0.0;
var oldZ : float = 0.0;
var newX : float = 0.0;
var newZ : float = 0.0;
var totalDistance : float = 0.0;
var dist : float = 0.0;
var stepLength : float;
stepLength = 5.0;
var prefab : Transform;

var crouchRacio : float = 0.5;
var transitionToCrouchSec : float = 0.2;
var crouchingVelocity : float;
var currentCrouchRacio : float = 1;
var originalLocalScaleY : float;
var crouchLocalScaleY : float;

var standDownCrouch : boolean = false;
var crouchUpStand : boolean = false;

    
var maxDist : float = 5.0;
var decalHitWall : GameObject;
var floatInFrontOfWall : float = 0.01;
var hit : RaycastHit;

function Start () {
	currentPosition = positions[2];
	movementSpeed = speedAndStance[2][1];

	currentCrouchRacio = 1;
    originalLocalScaleY = transform.localScale.y;
    crouchLocalScaleY = transform.localScale.y * crouchRacio;
}

function Update ()
{
	
	
	
	if (!networkView.isMine){
	
	GetComponentInChildren(Camera).enabled = false; 
	
	// disable the camera of the non-owned Player; 
	
	GetComponentInChildren(AudioListener).enabled = false; 
	
	// Disables AudioListener of non-owned Player - prevents multiple AudioListeners from being present in scene. 
	
	GetComponentInChildren(MouseLook).enabled = false;
	GetComponentInChildren(PlayerMovement).enabled = false; 
	
	
	
	} 
	
	
	
    /*if (Input.GetButton("Crouch")){
        currentCrouchRacio = Mathf.SmoothDamp(currentCrouchRacio, 0, crouchingVelocity, transitionToCrouchSec);
	}
    if (Input.GetButton("Crouch") == false && collisionDetectionSphere.GetComponent(CollsionDetectionSphereScript).collisionDetected == false){
        currentCrouchRacio = Mathf.SmoothDamp(currentCrouchRacio, 1, crouchingVelocity, transitionToCrouchSec);
    }*/
	
	
	transform.rotation = Quaternion.Euler(0, cameraObject.GetComponent(MouseLook).currentYRotation, 0);
	//currentCrouchRacio = Mathf.SmoothDamp(currentCrouchRacio, 0, crouchingVelocity, transitionToCrouchSec);
	
	var controller : CharacterController = GetComponent(CharacterController);
    
    /*if (currentPosition == positions[2]){
    	Debug.Log("blargle");
    	transform.localScale.y = Mathf.Lerp(crouchLocalScaleY, originalLocalScaleY, currentCrouchRacio);
    }*/
    
    transform.localScale.y = Mathf.Lerp(crouchLocalScaleY, originalLocalScaleY, currentCrouchRacio);
    //currentCrouchRacio = Mathf.SmoothDamp(currentCrouchRacio, 1, crouchingVelocity, transitionToCrouchSec);
    
    if (Input.GetKeyDown("left alt")){ // press C to crouch
        
        if(currentPosition == positions[2]){
			crouchUpStand = false;
			currentPosition = positions[1];
			movementSpeed = speedAndStance[1][1];
			//currentCrouchRacio = Mathf.SmoothDamp(currentCrouchRacio, 0, crouchingVelocity, transitionToCrouchSec);
			standDownCrouch = true;
			}
		else if(currentPosition == positions[1]){
			currentPosition = positions[0];
			movementSpeed = speedAndStance[0][0];
			}
    }
    
    if(standDownCrouch){
    	Debug.Log("blargle");
		currentCrouchRacio = Mathf.SmoothDamp(currentCrouchRacio, 0, crouchingVelocity, transitionToCrouchSec);
		
		}
    
    if(Input.GetKeyDown("left shift"))
    	speedOneUp = true;
    if(Input.GetKeyUp("left shift"))
    	speedOneUp = false;
    	
    if(Input.GetKeyDown("left ctrl"))
    	speedOneDown = true;
    if(Input.GetKeyUp("left ctrl"))
    	speedOneDown = false;
    
	if((speedOneUp == false) && (speedOneDown == false)){
		if(currentPosition == positions[2]){
			movementSpeed = speedAndStance[2][1];
			}
		else if(currentPosition == positions[1]){
			movementSpeed = speedAndStance[1][1];
			}
		else if(currentPosition == positions[0]){
			movementSpeed = speedAndStance[0][0];
			}
		}
	else if(speedOneUp){
		if(currentPosition == positions[2]){
			movementSpeed = speedAndStance[2][2];
			}
		else if(currentPosition == positions[1]){
			movementSpeed = speedAndStance[1][2];
			}
		else if(currentPosition == positions[0]){
			movementSpeed = speedAndStance[0][1];
			}
		}
	else if(speedOneDown){
		if(currentPosition == positions[2]){
			movementSpeed = speedAndStance[2][0];
			}
		else if(currentPosition == positions[1]){
			movementSpeed = speedAndStance[1][0];
			}
		}
    
    if (controller.isGrounded) {
		// We are grounded, so recalculate
		// move direction directly from axes
		moveDirection = Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
		moveDirection = transform.TransformDirection(moveDirection);
		moveDirection *= movementSpeed;
		
		if (Input.GetKeyDown("space")) {
			if(currentPosition == positions[2]){
				moveDirection.y = jumpSpeed;
				}
			else if(currentPosition == positions[1]){
				standDownCrouch = false;
				currentPosition = positions[2];
				movementSpeed = speedAndStance[2][1];
				//currentCrouchRacio = Mathf.SmoothDamp(currentCrouchRacio, 1, crouchingVelocity, transitionToCrouchSec);
				crouchUpStand = true;
				transform.position.y = 1.2;
				}
			else if(currentPosition == positions[0]){
				currentPosition = positions[1];
				movementSpeed = speedAndStance[1][1];
				}
		}
		
	}
	if(crouchUpStand){
		currentCrouchRacio = Mathf.SmoothDamp(currentCrouchRacio, 1, crouchingVelocity, 0.05);	
	}
	// Apply gravity
	moveDirection.y -= gravity * Time.deltaTime;
    
    
    
    
    
    // Move the controller
    oldX = controller.transform.position.x;
    oldZ = controller.transform.position.z;
    controller.Move(moveDirection * Time.deltaTime);
    newX = controller.transform.position.x;
    newZ = controller.transform.position.z;
    dist = Math.Sqrt(Math.Pow((newX-oldX),2) + Math.Pow((newZ-oldZ),2));
    totalDistance += dist;
    
    if(totalDistance >= stepLength)
    {
    	totalDistance = 0.0;
    	//makeTrack();
    	if (Physics.Raycast(transform.position, Vector3(0, -1, 0), hit, maxDist))//transform.up, hit, maxDist))
	    {
	        Debug.Log("Track made!! kar01");
	        /*if (decalHitWall && hit.transform.tag == "Level Parts")
	        {
	            Debug.Log("Track made!! kar02");
	            Network.Instantiate(decalHitWall, hit.point + (hit.normal * floatInFrontOfWall), Quaternion.LookRotation(hit.normal), 0);
	        }*/
	        Debug.Log("Track made!! kar02");
	        Network.Instantiate(decalHitWall, hit.point + (hit.normal * floatInFrontOfWall), Quaternion.identity, 0);//LookRotation(hit.normal), 0);
	    }
	    Debug.Log("Track made!! kar03");
    }
    


    /*if (Physics.Raycast(transform.position, transform.up, hit, maxDist))
    {
        if (decalHitWall && hit.transform.tag == "Level Parts")
            Instantiate(decalHitWall, hit.point + (hit.normal * floatInFrontOfWall), Quaternion.LookRotation(hit.normal));
    }*/
    //Destroy(gameObject);


	
}


/*function makeTrack() {
	Network.Instantiate(prefab, transform.position, Quaternion.identity, 0);
	Debug.Log("Track made!!");
}*/