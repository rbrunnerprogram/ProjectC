﻿#pragma strict

import System;

var speeds = new Array();

var creepingSpeed : float = 2.0;
var walkingSpeed : float = 6.0;
var joggingSpeed : float = 16.0;
var sprintingSpeed : float = 30.0;

//speeds = [creepingSpeed, walkingSpeed, joggingSpeed, sprintingSpeed];

var speedOneUp : boolean = false;
var speedOneDown : boolean = false;

var movementSpeed : float = 0.0;

var positions = new Array();
//var subSpeeds = new Array();
//var subSpeeds : float[,];

var currentPosition : float = 0.0;

var prone : float = 0.1;
var crouching : float = 0.5;
var standing : float = 1.0;

positions = [prone, crouching, standing];
var subSpeeds = [[creepingSpeed, walkingSpeed], [creepingSpeed, walkingSpeed, joggingSpeed], [walkingSpeed, joggingSpeed, sprintingSpeed]];

var jumpSpeed : float = 8.0;
var gravity : float = 20.0;

private var moveDirection : Vector3 = Vector3.zero;

//var walkAcceleration : float = 5;
var cameraObject : GameObject;
/*var maxWalkSpeed : float = 20;
var horizontalMovement : Vector2;*/

var oldX : float = 0.0;
var oldZ : float = 0.0;
var newX : float = 0.0;
var newZ : float = 0.0;
var totalDistance : float = 0.0;
var dist : float = 0.0;
var stepLength : float;
stepLength = 5.0;
var prefab : Transform;

function Start () {
	currentPosition = positions[2];
	movementSpeed = subSpeeds[2][1];
}

function Update ()
{
	
	/*if(!networkView.isMine)
	{
		this.enabled = false;
		return;
	}*/
	
	if (!networkView.isMine){ GetComponentInChildren(Camera).enabled = false; 
	
	// disable the camera of the non-owned Player; 
	
	GetComponentInChildren(AudioListener).enabled = false; 
	
	// Disables AudioListener of non-owned Player - prevents multiple AudioListeners from being present in scene. 
	
	GetComponentInChildren(MouseLook).enabled = false; GetComponentInChildren(PlayerMovement).enabled = false; 
	
	
	
	} 

	
	/*horizontalMovement = Vector2(rigidbody.velocity.x, rigidbody.velocity.z);
	if (horizontalMovement.magnitude > maxWalkSpeed)
	{
		horizontalMovement = horizontalMovement.normalized;
		horizontalMovement *= maxWalkSpeed;		
	}
	rigidbody.velocity.x = horizontalMovement.x;
	rigidbody.velocity.z = horizontalMovement.y;
	*/
	transform.rotation = Quaternion.Euler(0, cameraObject.GetComponent(MouseLook).currentYRotation, 0);
	//rigidbody.AddRelativeForce(Input.GetAxis("Horizontal") * walkAcceleration, 0, Input.GetAxis("Vertical") * walkAcceleration);
	
	var controller : CharacterController = GetComponent(CharacterController);
    //moveDirection = Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
    //moveDirection = transform.TransformDirection(moveDirection);
    
    //var h = height;
    if (Input.GetKey("c")){ // press C to crouch
        //h = 0.5 * height;
        //speed = crchSpeed; // slow down when crouching
        if(currentPosition == positions[2]){
			currentPosition = positions[1];
			movementSpeed = subSpeeds[1][1];
			//theCamera.position += Vector3.down * 0.5;
			}
		else if(currentPosition == positions[1]){
			currentPosition = positions[0];
			movementSpeed = subSpeeds[0][0];
			}
    }
    //var lastHeight = ch.height; // crouch/stand up smoothly 
    //ch.height = Mathf.Lerp(ch.height, h, 5*Time.deltaTime);
    //tr.position.y += (ch.height-lastHeight)/2; // fix vertical position
    
    if(Input.GetKeyDown("left shift"))
    	speedOneUp = true;
    if(Input.GetKeyUp("left shift"))
    	speedOneUp = false;
    	
    if(Input.GetKeyDown("left ctrl"))
    	speedOneDown = true;
    if(Input.GetKeyUp("left ctrl"))
    	speedOneDown = false;
    
	if((speedOneUp == false) && (speedOneDown == false)){
		if(currentPosition == positions[2]){
			movementSpeed = subSpeeds[2][1];
			}
		else if(currentPosition == positions[1]){
			movementSpeed = subSpeeds[1][1];
			}
		else if(currentPosition == positions[0]){
			movementSpeed = subSpeeds[0][0];
			}
		}
	else if(speedOneUp){
		if(currentPosition == positions[2]){
			movementSpeed = subSpeeds[2][2];
			}
		else if(currentPosition == positions[1]){
			movementSpeed = subSpeeds[1][2];
			}
		else if(currentPosition == positions[0]){
			movementSpeed = subSpeeds[0][1];
			}
		}
	else if(speedOneDown){
		if(currentPosition == positions[2]){
			movementSpeed = subSpeeds[2][0];
			}
		else if(currentPosition == positions[1]){
			movementSpeed = subSpeeds[1][0];
			}
		}
    
    if (controller.isGrounded) {
		// We are grounded, so recalculate
		// move direction directly from axes
		moveDirection = Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
		moveDirection = transform.TransformDirection(moveDirection);
		moveDirection *= movementSpeed;
		
		if (Input.GetKeyUp("v")) {
			if(currentPosition == positions[2]){
				moveDirection.y = jumpSpeed;
				}
			else if(currentPosition == positions[1]){
				currentPosition = positions[2];
				movementSpeed = subSpeeds[2][1];
				}
			else if(currentPosition == positions[0]){
				currentPosition = positions[1];
				movementSpeed = subSpeeds[1][1];
				}
		}
	}
	// Apply gravity
	moveDirection.y -= gravity * Time.deltaTime;
    
    
    
    //moveDirection *= movementSpeed;
    
    // Move the controller
    oldX = controller.transform.position.x;
    oldZ = controller.transform.position.z;
    controller.Move(moveDirection * Time.deltaTime);
    newX = controller.transform.position.x;
    newZ = controller.transform.position.z;
    dist = Math.Sqrt(Math.Pow((newX-oldX),2) + Math.Pow((newZ-oldZ),2));
    totalDistance += dist;
    //Debug.Log(stepLength);
    if(totalDistance >= stepLength)
    {
    	totalDistance = 0.0;
    	makeTrack();
    }
	
}


function makeTrack() {
	Network.Instantiate(prefab, transform.position, Quaternion.identity, 0);
	Debug.Log("Track made!!");
}